"use client"

import { useState } from "react"
import LoadingScreen from "@/components/loading-screen"
import LandingPage from "@/components/landing-page"

export default function Home() {
  const [loading, setLoading] = useState(true)

  return (
    <main>
      {loading && <LoadingScreen onLoadingComplete={() => setLoading(false)} />}
      <LandingPage />
    </main>
  )
}

