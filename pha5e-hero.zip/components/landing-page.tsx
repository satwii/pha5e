"use client"

import { useEffect, useRef } from "react"
import gsap from "gsap"

export default function LandingPage() {
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Fade in landing page content
    gsap.from(contentRef.current, {
      opacity: 0,
      y: 30,
      duration: 1,
      ease: "power2.out",
    })
  }, [])

  return (
    <div className="min-h-screen bg-[#1C1C1C] text-white">
      <div className="container mx-auto px-4">
        <div ref={contentRef} className="pt-32 pb-20">
          <div className="row justify-content-center text-center">
            <div className="col-lg-8">
              <h1 className="display-4 fw-bold mb-4">Welcome to PHA5E</h1>
              <p className="lead text-gray-400 mb-5">Discover the next generation of digital experiences</p>
              <button className="btn btn-outline-light btn-lg">Get Started</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

