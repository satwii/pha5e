"use client"

import { useEffect, useRef } from "react"
import gsap from "gsap"

interface LoadingScreenProps {
  onLoadingComplete: () => void
}

export default function LoadingScreen({ onLoadingComplete }: LoadingScreenProps) {
  const pathRefs = useRef<(SVGPathElement | null)[]>([])
  const loadingRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Get path lengths and set initial states
    pathRefs.current.forEach((path) => {
      if (path) {
        const length = path.getTotalLength()
        path.style.strokeDasharray = `${length}`
        path.style.strokeDashoffset = `${length}`
      }
    })

    // Create animation timeline
    const tl = gsap.timeline({
      onComplete: () => {
        // Fade out loading screen
        gsap.to(containerRef.current, {
          opacity: 0,
          duration: 0.5,
          delay: 1,
          onComplete: onLoadingComplete,
        })
      },
    })

    // Animate each path
    pathRefs.current.forEach((path, index) => {
      tl.to(path, {
        strokeDashoffset: 0,
        duration: 1.5,
        ease: "power2.inOut",
        delay: index === 0 ? 0 : 0.2,
      })
    })

    // Animate loading text
    tl.to(loadingRef.current, {
      opacity: 1,
      duration: 1,
      delay: 0.5,
    })

    return () => {
      tl.kill()
    }
  }, [onLoadingComplete])

  return (
    <div ref={containerRef} className="fixed inset-0 bg-[#1C1C1C] flex flex-col items-center justify-center z-50">
      <div className="container text-center">
        <svg viewBox="0 0 400 100" className="w-full max-w-[600px] mx-auto" stroke="white" strokeWidth="2" fill="none">
          {/* P */}
          <path
            ref={(el) => (pathRefs.current[0] = el)}
            d="M 50,20 L 50,80 M 50,20 L 80,20 Q 100,20 100,40 L 100,40 Q 100,60 80,60 L 50,60"
          />
          {/* H */}
          <path ref={(el) => (pathRefs.current[1] = el)} d="M 120,20 L 120,80 M 120,50 L 160,50 M 160,20 L 160,80" />
          {/* A */}
          <path ref={(el) => (pathRefs.current[2] = el)} d="M 180,80 L 200,20 L 220,80 M 190,50 L 210,50" />
          {/* 5 */}
          <path
            ref={(el) => (pathRefs.current[3] = el)}
            d="M 260,20 L 240,20 L 240,45 Q 260,45 270,50 Q 280,60 270,70 Q 260,80 240,80"
          />
          {/* E */}
          <path
            ref={(el) => (pathRefs.current[4] = el)}
            d="M 300,20 L 340,20 M 300,20 L 300,80 M 300,50 L 330,50 M 300,80 L 340,80"
          />
        </svg>
        <div
          ref={loadingRef}
          className="text-gray-400 mt-8 opacity-0 tracking-wider loading-dots"
          style={{ fontFamily: "monospace" }}
        >
          Loading
        </div>
      </div>
    </div>
  )
}

