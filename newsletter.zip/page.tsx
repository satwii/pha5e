"use client"

import { useEffect, useState } from "react"
import LoadingScreen from "./loading-screen"
import Hero from "./hero"

export default function Page() {
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  return <>{loading ? <LoadingScreen /> : <Hero />}</>
}

