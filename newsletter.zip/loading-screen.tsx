export default function LoadingScreen() {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black">
      <div className="flex flex-col items-center space-y-4">
        <svg
          width="120"
          height="40"
          viewBox="0 0 120 40"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="text-white"
        >
          <path
            d="M10 10h15v20h-15zM25 10h5v20M35 10h15v20h-15M55 10h15M75 10h15v20h-15M95 10h5v20"
            stroke="currentColor"
            strokeWidth="0.5"
          />
        </svg>
        <span className="text-xs tracking-[0.3em] text-neutral-600">Loading...</span>
      </div>
    </div>
  )
}

