export default function Hero() {
  return (
    <div className="relative min-h-screen w-full bg-black text-white">
      {/* Grid Background */}
      <div className="absolute inset-0 overflow-hidden opacity-20">
        {Array.from({ length: 20 }).map((_, i) => (
          <div key={i} className="absolute left-0 right-0 h-px bg-white/20" style={{ top: `${i * 5}vh` }} />
        ))}
        {Array.from({ length: 20 }).map((_, i) => (
          <div key={i} className="absolute bottom-0 top-0 w-px bg-white/20" style={{ left: `${i * 5}vw` }} />
        ))}
      </div>

      {/* Content */}
      <div className="relative flex min-h-screen flex-col items-center justify-center px-4 text-center">
        <h1 className="mb-6 text-4xl font-light tracking-[0.2em] sm:text-5xl md:text-6xl lg:text-7xl">
          PHASE FIVE DIGITAL
        </h1>
        <p className="mb-12 max-w-2xl text-sm font-light tracking-wider text-neutral-400 sm:text-base">
          Elevating brands through innovative digital solutions. We create impactful digital experiences that drive
          results and transform businesses.
        </p>
        <button className="group relative overflow-hidden border border-white/20 px-8 py-4 text-sm tracking-widest transition-colors hover:bg-white hover:text-black">
          GET STARTED
          <div className="absolute inset-0 -z-10 translate-y-full bg-white transition-transform duration-300 group-hover:translate-y-0" />
        </button>
      </div>
    </div>
  )
}

