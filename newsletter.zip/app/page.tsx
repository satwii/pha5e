"use client"

import NewsletterSignup from "../newsletter-signup"

export default function SyntheticV0PageForDeployment() {
  return <NewsletterSignup />
}